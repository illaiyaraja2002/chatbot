package com.example.chatbot.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class ChatbotServiceTest {

    private final ChatbotService service = new ChatbotService();

    @Test
    void greetsUser() {
        String reply = service.reply("Hello");
        assertTrue(reply.contains("Hello") || reply.contains("Hi"));
    }

    @Test
    void explainsSpringBoot() {
        assertTrue(service.reply("what is spring boot?").contains("Spring Boot"));
    }

    @Test
    void sayingGoodbyeWorks() {
        String reply = service.reply("bye");
        assertTrue(reply.contains("Goodbye") || reply.contains("See you"));
    }

    @Test
    void unknownInputGetsFallback() {
        assertTrue(service.reply("zzzxqv").startsWith("Sorry"));
    }

    @Test
    void blankInputIsHandled() {
        assertEquals("Please type something so I can respond.", service.reply("   "));
    }
}
