package com.example.chatbot.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;

/**
 * A tiny rule-based chatbot. Each rule has a regex and a reply supplier;
 * the first rule whose regex matches the user's message wins.
 *
 * To teach the bot something new, add a line to {@link #RULES}.
 */
@Service
public class ChatbotService {

    private record Rule(Pattern pattern, Supplier<String> reply) {
        static Rule of(String regex, Supplier<String> reply) {
            return new Rule(Pattern.compile(regex, Pattern.CASE_INSENSITIVE), reply);
        }

        static Rule of(String regex, String... replies) {
            return of(regex, () -> replies[ThreadLocalRandom.current().nextInt(replies.length)]);
        }
    }

    private static final List<Rule> RULES = List.of(
            Rule.of("\\b(hi|hello|hey|hola|namaste|vanakkam)\\b",
                    "Hello! How can I help you today?",
                    "Hi there! Ask me anything, or type 'help' to see what I can do."),
            Rule.of("how are you|how's it going",
                    "I'm just a bunch of Java code, but I'm doing great! How about you?"),
            Rule.of("your name|who are you",
                    "I'm SimpleBot, an open-source chatbot built with Java and Spring Boot."),
            Rule.of("\\bhelp\\b|what can you do",
                    "I can chat, tell the time and date, tell a joke, and answer a few questions "
                            + "about Java and Spring Boot. Try: 'time', 'joke', 'what is spring boot'."),
            Rule.of("\\b(time|clock)\\b",
                    () -> "The server time is "
                            + LocalDateTime.now().format(DateTimeFormatter.ofPattern("hh:mm a")) + "."),
            Rule.of("\\b(date|today)\\b",
                    () -> "Today is "
                            + LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy")) + "."),
            Rule.of("\\bjoke\\b",
                    "Why do Java developers wear glasses? Because they don't C#.",
                    "There are 10 kinds of people: those who understand binary and those who don't.",
                    "A SQL query walks into a bar, sees two tables and asks: 'Can I join you?'"),
            Rule.of("spring ?boot",
                    "Spring Boot makes it easy to create stand-alone, production-grade Spring applications "
                            + "with minimal configuration."),
            Rule.of("rest( ?api)?",
                    "A REST API exposes resources over HTTP using methods like GET, POST, PUT and DELETE, "
                            + "usually exchanging JSON."),
            Rule.of("\\bjava\\b",
                    "Java is a popular, object-oriented language that runs on the JVM: write once, run anywhere."),
            Rule.of("thank(s| you)",
                    "You're welcome!", "Happy to help!"),
            Rule.of("\\b(bye|goodbye|see you|exit|quit)\\b",
                    "Goodbye! Have a great day!", "See you later!")
    );

    private static final String FALLBACK =
            "Sorry, I didn't understand that. Type 'help' to see what I can do.";

    /**
     * Produces a reply for the given user message.
     */
    public String reply(String message) {
        if (message == null || message.isBlank()) {
            return "Please type something so I can respond.";
        }
        String normalized = message.trim().toLowerCase(Locale.ROOT);
        return RULES.stream()
                .filter(rule -> rule.pattern().matcher(normalized).find())
                .findFirst()
                .map(rule -> rule.reply().get())
                .orElse(FALLBACK);
    }
}
