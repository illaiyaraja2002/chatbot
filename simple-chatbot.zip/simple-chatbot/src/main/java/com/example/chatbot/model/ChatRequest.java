package com.example.chatbot.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Incoming chat message. {@code sessionId} is optional; if omitted the server creates one.
 */
public record ChatRequest(
        String sessionId,
        @NotBlank(message = "message must not be blank")
        @Size(max = 500, message = "message must be at most 500 characters")
        String message) {
}
