package com.example.chatbot.model;

import java.time.Instant;

/**
 * One entry in a conversation history. {@code sender} is "user" or "bot".
 */
public record ChatMessage(String sender, String text, Instant timestamp) {
}
