package com.example.chatbot.service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Component;

import com.example.chatbot.model.ChatMessage;

/**
 * In-memory conversation history, keyed by session id.
 * Each session keeps only the most recent {@value #MAX_MESSAGES} messages.
 * Swap this class for a database-backed implementation to persist chats.
 */
@Component
public class ConversationStore {

    private static final int MAX_MESSAGES = 100;

    private final Map<String, List<ChatMessage>> sessions = new ConcurrentHashMap<>();

    public void add(String sessionId, String sender, String text) {
        List<ChatMessage> history =
                sessions.computeIfAbsent(sessionId, id -> Collections.synchronizedList(new ArrayList<>()));
        synchronized (history) {
            history.add(new ChatMessage(sender, text, Instant.now()));
            while (history.size() > MAX_MESSAGES) {
                history.remove(0);
            }
        }
    }

    public List<ChatMessage> history(String sessionId) {
        List<ChatMessage> history = sessions.get(sessionId);
        if (history == null) {
            return List.of();
        }
        synchronized (history) {
            return List.copyOf(history);
        }
    }

    /** @return true if the session existed and was removed */
    public boolean clear(String sessionId) {
        return sessions.remove(sessionId) != null;
    }
}
