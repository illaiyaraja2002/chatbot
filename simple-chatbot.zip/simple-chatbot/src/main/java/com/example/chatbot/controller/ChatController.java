package com.example.chatbot.controller;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.chatbot.model.ChatMessage;
import com.example.chatbot.model.ChatRequest;
import com.example.chatbot.model.ChatResponse;
import com.example.chatbot.service.ChatbotService;
import com.example.chatbot.service.ConversationStore;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

    private final ChatbotService chatbot;
    private final ConversationStore store;

    public ChatController(ChatbotService chatbot, ConversationStore store) {
        this.chatbot = chatbot;
        this.store = store;
    }

    /** Send a message and get the bot's reply. */
    @PostMapping
    public ChatResponse chat(@Valid @RequestBody ChatRequest request) {
        String sessionId = (request.sessionId() == null || request.sessionId().isBlank())
                ? UUID.randomUUID().toString()
                : request.sessionId();

        String reply = chatbot.reply(request.message());
        store.add(sessionId, "user", request.message());
        store.add(sessionId, "bot", reply);

        return new ChatResponse(sessionId, reply, Instant.now());
    }

    /** Get the stored history of a session. */
    @GetMapping("/{sessionId}/history")
    public List<ChatMessage> history(@PathVariable String sessionId) {
        return store.history(sessionId);
    }

    /** Delete a session's history. */
    @DeleteMapping("/{sessionId}")
    public ResponseEntity<Void> clear(@PathVariable String sessionId) {
        return store.clear(sessionId)
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }
}
