package com.example.chatbot.model;

import java.time.Instant;

/**
 * Bot reply returned by the API.
 */
public record ChatResponse(String sessionId, String reply, Instant timestamp) {
}
