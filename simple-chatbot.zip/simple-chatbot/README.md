# SimpleBot: a simple chatbot with Java, Spring Boot and REST API

A small open-source, rule-based chatbot. It exposes a REST API, keeps per-session
chat history in memory, and ships with a minimal web chat page.

## Tech stack

- Java 17+
- Spring Boot 3.3 (Web, Validation)
- Maven
- JUnit 5 + MockMvc

## Getting started

```bash
git clone <your-repo-url>
cd simple-chatbot
mvn spring-boot:run
```

Open <http://localhost:8080> for the chat page, or use the API directly.

Run the tests:

```bash
mvn test
```

## REST API

| Method | Endpoint                       | Description                          |
|--------|--------------------------------|--------------------------------------|
| POST   | `/api/chat`                    | Send a message, get the bot's reply  |
| GET    | `/api/chat/{sessionId}/history`| Get a session's message history      |
| DELETE | `/api/chat/{sessionId}`        | Clear a session (404 if not found)   |

### Example

```bash
curl -X POST http://localhost:8080/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "hello"}'
```

```json
{
  "sessionId": "5f0c1c0e-...",
  "reply": "Hello! How can I help you today?",
  "timestamp": "2026-10-20T17:56:00Z"
}
```

Send the returned `sessionId` in later requests to keep the same conversation:

```bash
curl -X POST http://localhost:8080/api/chat \
  -H "Content-Type: application/json" \
  -d '{"sessionId": "5f0c1c0e-...", "message": "tell me a joke"}'
```

`message` is required and limited to 500 characters; an invalid request returns `400`.

## Project structure

```
src/main/java/com/example/chatbot/
  ChatbotApplication.java      # Spring Boot entry point
  controller/ChatController.java
  service/ChatbotService.java  # rule-based reply logic
  service/ConversationStore.java  # in-memory history
  model/                       # request/response records
src/main/resources/static/index.html   # web chat UI
```

## Teaching the bot new replies

Open `ChatbotService.java` and add a line to the `RULES` list:

```java
Rule.of("\\bweather\\b", "I can't check the weather yet, but it's always sunny in my code!"),
```

Rules are checked in order; the first regex that matches the message wins.

## Ideas for contributions

- Persist history with Spring Data JPA (H2 or PostgreSQL)
- Connect an LLM API for smarter answers
- Add Swagger / OpenAPI docs (`springdoc-openapi`)
- Docker support
- More intents and multi-language replies

## Contributing

1. Fork the repo and create a feature branch
2. Add tests for your change
3. Run `mvn test`
4. Open a pull request

## License

[MIT](LICENSE)
